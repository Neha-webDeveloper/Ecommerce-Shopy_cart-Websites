# About the project

A comprehensive CRM project to demonstrate Django's capabilities for managing customer relationships and data.

# Support

If you like this project and want to leave a donation, you are more than welcome to support this project down below:

[![Donate with Stripe](https://img.shields.io/badge/Donate%20with%20Stripe-6a1b9a?style=for-the-badge&logo=stripe&logoColor=white)](https://donate.stripe.com/28o4hEeFg5mcc3C9AE)

# Connect

Feel free to connect with me on the following platforms:

[![Subscribe on YouTube](https://img.shields.io/badge/Subscribe%20on%20YouTube-ff0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@CloudWithDjango)

[![Follow on X](https://img.shields.io/badge/Follow%20on%20X-000000?style=for-the-badge&logo=x&logoColor=white)](https://x.com/CloudWDjango)






